<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Theme_Kubo extends Theme
{


	public $name			= 'Kubo Theme';
	public $version		= '1.0';
	public $author		= 'Brayan Acebo';
	public $author_website	= 'http://brayanacebo';
	public $description	= 'Tema base de presentación';
	public $website		= 'http://brayanacebo.com/demos/kubo';

}

